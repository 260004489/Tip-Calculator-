package com.example.tipcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import java.text.NumberFormat;
import android.view.View.OnClickListener;
import android.widget.TextView.OnEditorActionListener;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;

public class MainActivity extends AppCompatActivity {
    // Declare reference variables for our widgets
    private EditText billAmountEditText;
    private TextView percentTextView;
    private TextView tipTextView;
    private TextView totalTextView;
    private Button decreaseButton;
    private Button increaseButton;

    // Our event handlers will be sharing these
    private String billAmountString = "0.00";
    private int tipPercentage = 15;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Initialize our widget reference variables
        billAmountEditText = findViewById(R.id.billAmountEditText);
        percentTextView = findViewById(R.id.percentTextView);
        tipTextView = findViewById(R.id.tipTextView);
        totalTextView = findViewById(R.id.totalTextView);
        decreaseButton = findViewById(R.id.decreaseButton);
        increaseButton = findViewById(R.id.increaseButton);

        // Set the event listeners for our interactive widgets
        billAmountEditText.setOnEditorActionListener( new BillAmountListener() );
        OnClickListener buttonEventListener = new ButtonListener();
        decreaseButton.setOnClickListener( buttonEventListener );
        increaseButton.setOnClickListener( buttonEventListener );

        // Update the percent, tip, and total TextView widgets based on the billAmountEditText
        calculateAndDisplay();
    }

    private void calculateAndDisplay() {
        // We will use locale-specific formatting for currency and percentage
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
        NumberFormat percentFormat = NumberFormat.getPercentInstance();

        // Get the billAmountEditText and convert it to a double
        billAmountString = billAmountEditText.getText().toString();
        double billAmount = (billAmountString.equals("") ? 0.0 : Double.parseDouble(billAmountString));

        // Recalculate the tip and total
        double tipAmount = billAmount * (tipPercentage / 100.0);
        double totalAmount = billAmount + tipAmount;

        // Display the results with locale-specific formatting
        percentTextView.setText(percentFormat.format(tipPercentage / 100.0));
        tipTextView.setText(currencyFormat.format(tipAmount));
        totalTextView.setText(currencyFormat.format(totalAmount));
    }

    class BillAmountListener implements OnEditorActionListener {
        @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            if ( actionId == EditorInfo.IME_ACTION_DONE ) {
                calculateAndDisplay();
            }
            return false;
        }
    }

    class ButtonListener implements OnClickListener {
        @Override
        public void onClick( View v ) {
            if (v.getId() == R.id.decreaseButton) {
                tipPercentage -= 1;
                if (tipPercentage < 0)
                    tipPercentage = 0;
            } else if (v.getId() == R.id.increaseButton) {
                tipPercentage += 1;
                if (tipPercentage > 100)
                    tipPercentage = 100;
            }
            calculateAndDisplay();
        }
    }
}